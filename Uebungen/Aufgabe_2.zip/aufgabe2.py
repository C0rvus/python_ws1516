# An der Loesung dieser Aufgabe waren folgende Personen beteiligt:
# <bitte ergaenzen>

from PIL import Image
import math

class KomplexeZahl(object):
	# Hier bitte Aufgabe 2a ergaenzen
	def __init__(self, re, im):
		pass


if __name__ == "__main__":
	breite, hoehe = 640, 480
	untenLinks, obenRechts = KomplexeZahl(-2.2, -1.3), KomplexeZahl(0.8, 1.3)
	maximaleIterationszahl = 20
	divergiertWennBetragGroesser = 2.0

	plakat = Image.new('RGB', (breite, hoehe))
	pixels = plakat.load()

	# Hier bitte Aufgabe 2b ergaenzen
	for x in range(0, breite):
		for y in range(0, hoehe):
			rot = x % 256 # Nur zur Demonstration
			gruen = x * y % 256 # Nur zur Demonstration
			blau = y % 256 # Nur zur Demonstration
			pixels[x, y] = (rot, gruen, blau) # Setze <Rot>, <Gruen> und <Blau> des Pixels x, y 
	
	plakat.save("plakat.png")
